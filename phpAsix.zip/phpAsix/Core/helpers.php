<?php
//funcions globals
function dd($var)
{
    var_dump($var);
    die();
}