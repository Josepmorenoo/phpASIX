<?php
    require 'app/index.php';
    require 'resources/views/index.blade.php';